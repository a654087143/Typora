package cn.yodocer;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * @author liujq
 */
public class CryptUtil {

    private static final List<String> WORDS = Arrays.asList("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f");

    /**
     * 获取随机AES秘钥
     * @return 16位的秘钥
     */
    public static String getRandKey() {
        WORDS.sort((a, b) -> Math.random() > 0.5 ? -1 : 1);
        return String.join("", WORDS);
    }
    /**
     * AES加密数据
     * @param dataStr 要加密的字符串
     * @param key 秘钥
     * @return String 加密后的字符串
     */
    public static String aesEncryptData(String dataStr, String key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        byte[] byteContent = dataStr.getBytes("UTF-8");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key.getBytes("UTF-8"), "AES"));
        byte[] result = cipher.doFinal(byteContent);
        return Base64.getEncoder().encodeToString(result);
    }

    /**
     * AES解密数据
     * @param encDataStr 要解密的字符串
     * @param key 秘钥
     * @return String 解密后的字符串
     */
    public static String aesDecryptData(String encDataStr, String key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key.getBytes("UTF-8"), "AES"));
        byte[] result = cipher.doFinal(org.apache.commons.codec.binary.Base64.decodeBase64(encDataStr));
        return new String(result, "UTF-8");
    }

    /**
     * RSA加密秘钥
     * @param randKey 要加密的AES秘钥
     * @param publicKey RSA公钥
     * @return String 加密后的AES秘钥
     */
    public static String rsaEncryptRandKey(String randKey, String publicKey) throws Exception {
        byte[] decoded = Base64.getDecoder().decode(publicKey.getBytes());
        RSAPublicKey pubKey = (RSAPublicKey) KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(decoded));
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, pubKey);
        return Base64.getEncoder().encodeToString(cipher.doFinal(randKey.getBytes("UTF-8")));
    }

    /**
     * RSA解密秘钥
     * @param encRandKey 要解密的AES秘钥
     * @param privateKey RSA私钥
     * @return String 解密后的AES秘钥
     */
    public static String rsaDescryptRandKey(String encRandKey, String privateKey) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(privateKey.getBytes());
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey priKey = keyFactory.generatePrivate(keySpec);
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, priKey);
        byte[] bytes = Base64.getDecoder().decode(encRandKey);
        return new String(cipher.doFinal(bytes));
    }
}
