import JsEncrypt from 'jsencrypt';
import CryptoJs from 'crypto-js';

const { AES, enc: { Utf8 }, pad: { Pkcs7 }, mode: { ECB } } = CryptoJs;

const words = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f'];

/**
 * 获取随机key
 */
export function getRandKey() {
  return words.sort(() => Math.random() - 0.5).join('');
}

/**
 * AES加密
 * @param { String } dataStr 要加密的数据字符串
 * @param { String } key 秘钥（长度16位）
 * @return { String } 加密后的字符串
 */
export function aesEncrypt(dataStr, key) {
  const encrypted = AES.encrypt(dataStr, Utf8.parse(key), { mode: ECB, padding: Pkcs7 });
  return encrypted.toString();
}

/**
 * AES解密
 * @param { String } encStr 要解密的字符串
 * @param { String } key 秘钥（长度16位）
 * @return { String } 解密后的字符串
 */
export function aesDecrypt(encDataStr, key) {
  const decrypted = AES.decrypt(encDataStr, Utf8.parse(key), { mode: ECB, padding: Pkcs7 });
  return decrypted.toString(Utf8);
}

/**
 * RSA加密
 * @param { String } str 要加密的字符串
 * @param { String } publicKey 公钥
 * @return { String } 加密后的字符串
 */
export function rsaEncrypt(str, publicKey) {
  const jsencrypt = new JsEncrypt();
  jsencrypt.setPublicKey(publicKey);
  return jsencrypt.encrypt(str);
}

/**
 * RSA解密
 * @param { String } encStr 要解密的字符串
 * @param { String } privateKey 私钥
 * @return { String } 解密后的字符串
 */
export function rsaDecrypt(encStr, privateKey) {
  const jsencrypt = new JsEncrypt();
  jsencrypt.setPrivateKey(privateKey);
  return jsencrypt.decrypt(encStr);
}
  
