package cn.yocoder;

import org.reactivestreams.Publisher;
import org.springframework.cloud.gateway.support.DefaultClientResponse;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.client.reactive.ClientHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static org.springframework.cloud.gateway.support.ServerWebExchangeUtils.ORIGINAL_RESPONSE_CONTENT_TYPE_ATTR;

/**
 * @author ljq
 */
public class ResponseAdapter implements ClientHttpResponse {

    private final Flux<DataBuffer> flux;
    private final HttpHeaders headers;

    public ResponseAdapter(Publisher<? extends DataBuffer> body, HttpHeaders headers) {
        this.headers = headers;
        if (body instanceof Flux) {
            flux = (Flux<DataBuffer>) body;
        } else {
            flux = ((Mono) body).flux();
        }
    }

    @Override
    public @NonNull
    Flux<DataBuffer> getBody() {
        return flux;
    }

    @Override
    public @NonNull
    HttpHeaders getHeaders() {
        return headers;
    }

    @Override
    public @NonNull
    HttpStatus getStatusCode() {
        return null;
    }

    @Override
    public int getRawStatusCode() {
        return 0;
    }

    @Override
    public @NonNull
    MultiValueMap<String, ResponseCookie> getCookies() {
        return null;
    }

    public static DefaultClientResponse createClientResponse(ServerWebExchange exchange, Publisher<? extends DataBuffer> body) {
        String originalResponseContentType = exchange.getAttribute(ORIGINAL_RESPONSE_CONTENT_TYPE_ATTR);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, originalResponseContentType);
        ResponseAdapter responseAdapter = new ResponseAdapter(body, httpHeaders);
        return new DefaultClientResponse(responseAdapter, ExchangeStrategies.withDefaults());
    }
}

