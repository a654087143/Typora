package cn.yodocer;

import java.net.URI;
import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.alibaba.fastjson.JSON;

import org.reactivestreams.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.cloud.gateway.support.BodyInserterContext;
import org.springframework.cloud.gateway.support.CachedBodyOutputMessage;
import org.springframework.cloud.gateway.support.DefaultClientResponse;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.core.io.buffer.NettyDataBufferFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.server.ServerWebExchange;

import io.netty.buffer.ByteBufAllocator;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * 报文加解密
 * @author ljq
 */
@Component
public class CryptFilter implements GlobalFilter, Ordered {

    private Logger log = LoggerFactory.getLogger(getClass());

    // RSA秘钥对
    private final String PRIVATEKEY1  = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAJ+kRAITvJ9SlkDnu0ynWsYk1YHvLiCyEaVNaBTJG9DXDI83frHsRrC/r+VQrede9nTBuidZozARG4T14GNhnxb4Ns++jTnNbTM/NlVNmEvMlw1j/IS0BkTUwQAVO99axQP3FRWewUxePHt3UowhVRWCQ3wud4c1/Q/EDYq9WQ5VAgMBAAECgYBMJXI6+2cRJ7d7pgz09y6ZLKCapZd/CPDZxB5NK9AUwT7AYVwRSf49+HDSFLWekvFDp9Q/SMZJ+x8BQLaTMNFMwr/C7rZjQ9U9B7NVAXHSYj57J3f10DXcKAATd2zNn32rGriloPPYm7q9XQHsHPvDciWXRpXzA+3XROb94SlUAQJBAPcXafX4/bCcJSblCNag2bEkUoqcaPiiLzAYRHNioBoxyE8LqRPyN9uHmMmC7E2/OHazIYijg6ZDUcEIlX8QOZUCQQClZbbWjkG6ijnqt1Ujm7ng3uI9jh9EtpCh59QKaI15i9dh565OZFflcW3E+fh6MO8cltx24Gp4XMhwYNHt79HBAkEA8I6+/lXWxmZ+VQuOO0aGKcuvAHueRtG/FxfJLHzMWjQ1S5+SkHS0pOmyeh0YaejM0+M5tola1jecFE6DHR1ysQJBAJEdONnuXkToWgBRceWYD/H4G8+eDlkfRK6I1EV9jgMCaqp/tzMYXvX0GzcjiprKrEANLMkwBLotzb6rdASq0QECQEqZJLFoCX7VXChbnF+bXNMQSH5HPeVfjjW/PV42IVp5+JSi34TqzHbD+A8sGx5k2fAxkCo+0WQROpI6a4jTwW4=";
    private final String PUBLICKEY1 = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCfpEQCE7yfUpZA57tMp1rGJNWB7y4gshGlTWgUyRvQ1wyPN36x7Eawv6/lUK3nXvZ0wbonWaMwERuE9eBjYZ8W+DbPvo05zW0zPzZVTZhLzJcNY/yEtAZE1MEAFTvfWsUD9xUVnsFMXjx7d1KMIVUVgkN8LneHNf0PxA2KvVkOVQIDAQAB";

    // RSA秘钥对
    private final String PRIVATEKEY2 = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAKGXGzW2v6OyRFOp32bbCRt5svL3vP8uXpidza+hP7D0YarDU44Mvq7ttvYIGid81jw1424VvFLaXV8x3IWGU3xHTnI4jcrvj6hbIo6vd8RwO8UG+QMOSBRmg0R69PRcp58fQID41tWfh1lBh3ebuqJ64utbQMR0Fpog2vXLYlQrAgMBAAECgYArBJY6037rLl8gQr31nOQsy1ZHdop7CLYoPQJv+iaBjl2d30gULfJpkWE+2GNWFdbWyqXUPbcX+4gV+qkxZtQ8ekFeKRTIq+nSuJ4sAseAzMcZk8IoPTTRgcIpNg/i9gSG/jBrrLT9C/m5eelMfoGUvdWTosrU4Ge+ZJkv5qRMgQJBANPW6fdyVfAFcPCkz51gQmRTUa+LtvepfUKgXRQX7xf0o+p41yPtyYfEBVO4vS+3/lRUCfQS4CoB1nwuVNkt+MECQQDDRpO1FWLSohwHmMAKMLFr6jxGmdRwdiQf6jJkbRv0SKzXf18ZpMb/hsuIsvnA5H/MqqZLdIDNiswAeY8t+rvrAkEAh+bMWo7jSwRynC9fchsa/LnnIbOEQgZd8axnikiAfuHXdsjnXIlkTNEYiclutXpYk0kGyaqCXPCo5SnkDSBNAQJBAJDZOFWZcH13nD0SVFj6t5Cp5l4kW020hKVbzldqC9NPWU5cf8mAzc/bR/y1bcdkd1v0tXfBCo3sx9gOU2Oy2lMCQQCup3Yr3taBvDHByE74bLojyFZUgYbMhdaHXPfh9ZVJXNqOyW4tpb6A/QC8qV5wUe1USvXURz44DRgpz0U2teGR";
    private final String PUBLICKEY2 = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChlxs1tr+jskRTqd9m2wkbebLy97z/Ll6Ync2voT+w9GGqw1OODL6u7bb2CBonfNY8NeNuFbxS2l1fMdyFhlN8R05yOI3K74+oWyKOr3fEcDvFBvkDDkgUZoNEevT0XKefH0CA+NbVn4dZQYd3m7qieuLrW0DEdBaaINr1y2JUKwIDAQAB";

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        try {
            ServerHttpRequest serverHttpRequest = exchange.getRequest();
            String method = serverHttpRequest.getMethodValue();
            String bodyStr = resolveBodyFromRequest(exchange.getRequest());
            ServerHttpResponseDecorator response = null;
            // post请求，并且数据中包含encRandKey字段时，解密入参，加密出参
            if ("POST".equals(method) && bodyStr.contains("encRandKey")) {
                // 解密入参
                bodyStr = decryptRequest(bodyStr);
                // 加密出参
                response = encryptResponse(exchange);
            }

            // 将请求体再次封装写回到request里，传到下一级，否则，由于请求体已被消费，后续的服务将取不到值
            URI uri = serverHttpRequest.getURI();
            ServerHttpRequest request = serverHttpRequest.mutate().uri(uri).build();
            DataBuffer bodyDataBuffer = stringBuffer(bodyStr);
            Flux<DataBuffer> bodyFlux = Flux.just(bodyDataBuffer);
            HttpHeaders headers = new HttpHeaders();
            headers.putAll(exchange.getRequest().getHeaders());
            // 由于修改了传递参数，需要重新设置CONTENT_LENGTH，长度是字节长度，不是字符串长度
            int length = bodyStr.getBytes().length;
            headers.remove(HttpHeaders.CONTENT_LENGTH);
            headers.setContentLength(length);
            request = new ServerHttpRequestDecorator(request){
                @Override
                public HttpHeaders getHeaders() {
                    long contentLength = headers.getContentLength();
                    HttpHeaders httpHeaders = new HttpHeaders();
                    httpHeaders.putAll(super.getHeaders());
                    if (contentLength > 0) {
                        httpHeaders.setContentLength(contentLength);
                    } else {
                        httpHeaders.set(HttpHeaders.TRANSFER_ENCODING, "chunked");
                    }
                    return httpHeaders;
                }
                @Override
                public Flux<DataBuffer> getBody() {
                    return bodyFlux;
                }
            };

            return chain.filter(exchange.mutate().request(request).response(response).build());

        } catch (Exception e) {
            log.error("报文加解密异常", e);
        }
        return chain.filter(exchange);
    }

    /**
     * 解密入参
     * @param bodyStr
     * @return
     */
    private String decryptRequest(String bodyStr) throws Exception {
        log.debug("报文解密开始");
        Map<String, String> dataMap = JSON.parseObject(bodyStr, Map.class);
        String encRandKey = dataMap.get("encRandKey");
        String randKey = CryptUtil.rsaDescryptRandKey(encRandKey, PRIVATEKEY1);
        String encDataStr = dataMap.get("encDataStr");
        String dataStr = CryptUtil.aesDecryptData(encDataStr, randKey);
        log.info("入参：" + dataStr);
        log.debug("报文解密完成");
        return dataStr;
    }

    /**
     * 加密出参
     * @param exchange
     * @return
     */
    private ServerHttpResponseDecorator encryptResponse(ServerWebExchange exchange) {
        ServerHttpResponseDecorator decoratedResponse = new ServerHttpResponseDecorator(exchange.getResponse()) {
            @Override
            public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
                DefaultClientResponse clientResponse = ResponseAdapter.createClientResponse(exchange, body);
                Mono<String> modifiedBody = clientResponse.bodyToMono(String.class)
                    .flatMap(originalBody -> {
                        log.info("出参：" + originalBody);
                        try {
                            // 加密数据
                            String randKey = CryptUtil.getRandKey();
                            String encRandKey = CryptUtil.rsaEncryptRandKey(randKey, PUBLICKEY2);
                            String encDataStr = CryptUtil.aesEncryptData(originalBody, randKey);
                            String result = "{\"encRandKey\": \"" + encRandKey + "\", \"encDataStr\": \"" + encDataStr + "\"}";
                            return Mono.just(result);
                        } catch (Exception e) {
                            log.error("出参加密错误：", e);
                            return Mono.just("{\"error\": " + e.getMessage() + "\"}");
                        }
                    });
                return newBodyInsert(modifiedBody);
            }

            @Override
            public Mono<Void> writeAndFlushWith(@NonNull Publisher<? extends Publisher<? extends DataBuffer>> body) {
                return writeWith(Flux.from(body).flatMapSequential(p -> p));
            }

            private Mono<Void> newBodyInsert(Mono<String> modifiedBody) {
                BodyInserter bodyInserter = BodyInserters.fromPublisher(modifiedBody, String.class);
                CachedBodyOutputMessage outputMessage = new CachedBodyOutputMessage(exchange, exchange.getResponse().getHeaders());
                return bodyInserter.insert(outputMessage, new BodyInserterContext())
                        .then(Mono.defer(() -> {
                            Flux<DataBuffer> messageBody = outputMessage.getBody();
                            HttpHeaders headers = getDelegate().getHeaders();
                            if (!headers.containsKey(HttpHeaders.TRANSFER_ENCODING)) {
                                messageBody = messageBody.doOnNext(data -> headers.setContentLength(data.readableByteCount()));
                            }
                            return getDelegate().writeWith(messageBody);
                        }));
            }
        };
        return decoratedResponse;
    }

    /**
     * 获取post请求体
     * @param serverHttpRequest
     * @return
     */
    private String resolveBodyFromRequest(ServerHttpRequest serverHttpRequest) {
        Flux<DataBuffer> body = serverHttpRequest.getBody();

        AtomicReference<String> bodyRef = new AtomicReference<>();
        body.subscribe(buffer -> {
            CharBuffer charBuffer = StandardCharsets.UTF_8.decode(buffer.asByteBuffer());
            DataBufferUtils.release(buffer);
            bodyRef.set(charBuffer.toString());
        });
        return bodyRef.get();
    }

    private DataBuffer stringBuffer(String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        NettyDataBufferFactory nettyDataBufferFactory = new NettyDataBufferFactory(ByteBufAllocator.DEFAULT);
        DataBuffer buffer = nettyDataBufferFactory.allocateBuffer(bytes.length);
        buffer.write(bytes);
        return buffer;
    }

    @Override
    public int getOrder() {
        return -2;
    }

}
