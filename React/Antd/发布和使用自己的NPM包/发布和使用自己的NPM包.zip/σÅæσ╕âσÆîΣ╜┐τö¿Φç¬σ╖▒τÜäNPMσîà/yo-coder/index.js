
exports.yo = function() {
    alert('Yo Coder!')
}

exports.hello = function() {
    alert('Hello Coder!')
}