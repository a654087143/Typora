# 说明

1. yo-coder是一个npm模块, 发布到npm仓库
  - npm仓库地址: https://www.npmjs.com/package/yo-coder
  - 淘宝NPM镜像地址: https://npm.taobao.org/package/yo-coder

2. yo-coder-test是一个用vue-cli搭建的工程, 用来测试yo-coder是否可用
  - 可直接看yo-coder-test/src/App.vue文件里对yo-coder的使用

## 一个广告

欢迎访问 https://www.yocoder.cn 一个为程序员做的网站