---
category: Components
cols: 1
title: ButtonPlus
subtitle: 按钮
---

对按钮进行二次封装

## API

| 属性 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| type | 新增属性值为`del` | string | - |
