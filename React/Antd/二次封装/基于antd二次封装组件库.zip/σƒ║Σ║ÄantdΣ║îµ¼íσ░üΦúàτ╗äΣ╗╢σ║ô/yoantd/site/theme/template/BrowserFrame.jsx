import React from 'react';

export default ({ children }) => <div className="browser-mockup with-url">{children}</div>;
