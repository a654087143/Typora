/**
 * 封装Button
 * @author: 朽木
 * @since: 2019-01-10 22:59:52
 */
import * as React from 'react';
export default class ButtonPlus extends React.Component<any> {
    render(): JSX.Element;
}
