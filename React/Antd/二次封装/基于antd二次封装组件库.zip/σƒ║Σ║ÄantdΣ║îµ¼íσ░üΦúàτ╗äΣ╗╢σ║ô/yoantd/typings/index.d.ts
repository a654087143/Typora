/// <reference path="custom-typings.d.ts" />
