import createReactContext from 'create-react-context/lib/implementation';

export default createReactContext;
